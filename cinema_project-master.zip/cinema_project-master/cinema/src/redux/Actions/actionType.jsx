export const SHOW_MODAL_LOGIN = 'SHOW_MODAL_LOGIN';

export const LOGIN = 'LOGIN';

export const GET_FILM_LIST = 'GET_FILM_LIST';
export const GET_FILM_LIST_SOON = 'GET_FILM_LIST_SOON';

export const BOOK_TICKET = 'BOOK_TICKET';

export const GET_THEATERS = 'GET_THEATERS';
export const RELOAD_THEATERS = 'RELOAD_THEATERS';
export const GET_ID_RAP = 'GET_ID_RAP';


export const GET_USER_LIST = 'GET_USER_LIST';
export const DELETE_USER = 'DELETE_USER';
export const RESET_MESSAGE_USER = 'RESET_MESSAGE_USER';