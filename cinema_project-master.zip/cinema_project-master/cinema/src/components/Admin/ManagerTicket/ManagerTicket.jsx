import React from 'react';

const ManagerTicket = () => {
    return (
        <div>
            
        </div>
    )
}

export default ManagerTicket;
