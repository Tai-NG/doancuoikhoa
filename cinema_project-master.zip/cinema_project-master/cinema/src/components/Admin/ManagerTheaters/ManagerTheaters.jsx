import React from 'react';
import TableTheaters from './TableTheaters';


const ManagerTheaters = () => {
    return (
        <div className="manager__theaters">
            <TableTheaters/>
        </div>
    )
}

export default ManagerTheaters;
