export const API = 'https://movie0706.cybersoft.edu.vn/api';
export const API_NEWS = 'https://5f34bdac9124200016e18e40.mockapi.io/news';